setwd("C:\\Users\\IT23269248\\Desktop\\Lab 8")

data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
weights <- data$Weight

## Step 3: Calculate population mean and population standard deviation
pop_mean <- mean(weights)
pop_sd <- sd(weights)

cat("Population Mean:", pop_mean, "\n")
cat("Population Standard Deviation:", pop_sd, "\n")

## Step 4: Draw 25 random samples of size 6 (with replacement)
set.seed(123)  # For reproducibility
sample_means <- numeric(25)
sample_sds <- numeric(25)

for(i in 1:25) {
  sample_i <- sample(weights, 6, replace = TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
  cat("Sample", i, "Mean:", sample_means[i], "SD:", sample_sds[i], "\n")
}

## Step 5: Calculate mean and standard deviation of the 25 sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("\nMean of Sample Means:", mean_of_sample_means, "\n")
cat("Standard Deviation of Sample Means:", sd_of_sample_means, "\n")

## Step 6: State the relationship (can be printed or written in your Word doc)
cat("\nRelationship:\n")
cat("The mean of the sample means approximates the population mean.\n")
cat("The standard deviation of the sample means (standard error) is smaller than the population standard deviation.\n")


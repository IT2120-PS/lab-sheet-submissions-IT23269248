
setwd("C:\\Users\\IT23269248\\Desktop\\IT23269248")
Student_data<-read.csv("Exercise.csv",header = TRUE)

summary(Student_data$X1)

hist(Student_data$X1, main="Histogram of Age (X1)", xlab="Age", col="lightblue", border="black")


gender_table <- table(Student_data$X2)
print(gender_table)
barplot(gender_table, main="Gender Distribution", xlab="Gender", ylab="Frequency", col=c("lightgreen", "lightcoral"))



boxplot(X1 ~ X3, data=Student_data, main="Age Distribution by Accommodation Type", 
        xlab="Accommodation Type", ylab="Age", col=c("skyblue", "lightgreen", "lightpink"))


